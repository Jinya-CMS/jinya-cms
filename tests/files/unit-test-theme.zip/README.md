# jinya-testing-theme

A simple theme containing mainly theme options and no frontend
